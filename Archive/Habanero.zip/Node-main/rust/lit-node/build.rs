// Based on https://github.com/denoland/deno/blob/v1.36/runtime/build.rs
// Modified to add js_libs/lit/ to the V8 snapshot
#![allow(clippy::unwrap_used)]

#[cfg(all(
    feature = "lit-actions",
    not(feature = "docsrs"),
    not(feature = "dont_create_runtime_snapshot")
))]
mod startup_snapshot {
    use deno_runtime::*; // re-exports everything we need including deno_core

    use deno_ast::MediaType;
    use deno_ast::ParseParams;
    use deno_ast::SourceTextInfo;
    use deno_cache::SqliteBackedCache;
    use deno_core::error::AnyError;
    use deno_core::snapshot_util::*;
    use deno_core::Extension;
    use deno_core::ExtensionFileSource;
    use deno_core::ExtensionFileSourceCode;
    use deno_http::DefaultHttpPropertyExtractor;
    use std::path::Path;

    fn maybe_transpile_source(source: &mut ExtensionFileSource) -> Result<(), AnyError> {
        // Always transpile `node:` built-in modules, since they might be TypeScript.
        let media_type = if source.specifier.starts_with("node:") {
            MediaType::TypeScript
        } else {
            MediaType::from_path(Path::new(&source.specifier))
        };

        match media_type {
            MediaType::TypeScript => {}
            MediaType::JavaScript => return Ok(()),
            MediaType::Mjs => return Ok(()),
            _ => panic!(
                "Unsupported media type for snapshotting {media_type:?} for file {}",
                source.specifier
            ),
        }
        let code = source.load()?;

        let parsed = deno_ast::parse_module(ParseParams {
            specifier: source.specifier.to_string(),
            text_info: SourceTextInfo::from_string(code.as_str().to_owned()),
            media_type,
            capture_tokens: false,
            scope_analysis: false,
            maybe_syntax: None,
        })?;
        let transpiled_source = parsed.transpile(&deno_ast::EmitOptions {
            imports_not_used_as_values: deno_ast::ImportsNotUsedAsValues::Remove,
            inline_source_map: false,
            ..Default::default()
        })?;

        source.code = ExtensionFileSourceCode::Computed(transpiled_source.text.into());
        Ok(())
    }

    #[derive(Clone)]
    struct Permissions;

    impl deno_fetch::FetchPermissions for Permissions {
        fn check_net_url(
            &mut self,
            _url: &deno_core::url::Url,
            _api_name: &str,
        ) -> Result<(), deno_core::error::AnyError> {
            unreachable!("snapshotting!")
        }

        fn check_read(
            &mut self,
            _p: &Path,
            _api_name: &str,
        ) -> Result<(), deno_core::error::AnyError> {
            unreachable!("snapshotting!")
        }
    }

    impl deno_websocket::WebSocketPermissions for Permissions {
        fn check_net_url(
            &mut self,
            _url: &deno_core::url::Url,
            _api_name: &str,
        ) -> Result<(), deno_core::error::AnyError> {
            unreachable!("snapshotting!")
        }
    }

    impl deno_web::TimersPermission for Permissions {
        fn allow_hrtime(&mut self) -> bool {
            unreachable!("snapshotting!")
        }
    }

    // impl deno_ffi::FfiPermissions for Permissions {
    //     fn check_partial(
    //         &mut self,
    //         _path: Option<&Path>,
    //     ) -> Result<(), deno_core::error::AnyError> {
    //         unreachable!("snapshotting!")
    //     }
    // }

    // impl deno_napi::NapiPermissions for Permissions {
    //     fn check(&mut self, _path: Option<&Path>) -> Result<(), deno_core::error::AnyError> {
    //         unreachable!("snapshotting!")
    //     }
    // }

    impl deno_node::NodePermissions for Permissions {
        fn check_net_url(
            &mut self,
            _url: &deno_core::url::Url,
            _api_name: &str,
        ) -> Result<(), deno_core::error::AnyError> {
            unreachable!("snapshotting!")
        }
        fn check_read(&self, _p: &Path) -> Result<(), deno_core::error::AnyError> {
            unreachable!("snapshotting!")
        }
        fn check_sys(
            &self,
            _kind: &str,
            _api_name: &str,
        ) -> Result<(), deno_core::error::AnyError> {
            unreachable!("snapshotting!")
        }
    }

    impl deno_net::NetPermissions for Permissions {
        fn check_net<T: AsRef<str>>(
            &mut self,
            _host: &(T, Option<u16>),
            _api_name: &str,
        ) -> Result<(), deno_core::error::AnyError> {
            unreachable!("snapshotting!")
        }

        fn check_read(
            &mut self,
            _p: &Path,
            _api_name: &str,
        ) -> Result<(), deno_core::error::AnyError> {
            unreachable!("snapshotting!")
        }

        fn check_write(
            &mut self,
            _p: &Path,
            _api_name: &str,
        ) -> Result<(), deno_core::error::AnyError> {
            unreachable!("snapshotting!")
        }
    }

    impl deno_fs::FsPermissions for Permissions {
        fn check_read(&mut self, _path: &Path, _api_name: &str) -> Result<(), AnyError> {
            unreachable!("snapshotting!")
        }

        fn check_read_all(&mut self, _api_name: &str) -> Result<(), AnyError> {
            unreachable!("snapshotting!")
        }

        fn check_read_blind(
            &mut self,
            _path: &Path,
            _display: &str,
            _api_name: &str,
        ) -> Result<(), AnyError> {
            unreachable!("snapshotting!")
        }

        fn check_write(&mut self, _path: &Path, _api_name: &str) -> Result<(), AnyError> {
            unreachable!("snapshotting!")
        }

        fn check_write_partial(&mut self, _path: &Path, _api_name: &str) -> Result<(), AnyError> {
            unreachable!("snapshotting!")
        }

        fn check_write_all(&mut self, _api_name: &str) -> Result<(), AnyError> {
            unreachable!("snapshotting!")
        }

        fn check_write_blind(
            &mut self,
            _path: &Path,
            _display: &str,
            _api_name: &str,
        ) -> Result<(), AnyError> {
            unreachable!("snapshotting!")
        }
    }

    // impl deno_kv::sqlite::SqliteDbHandlerPermissions for Permissions {
    //     fn check_read(&mut self, _path: &Path, _api_name: &str) -> Result<(), AnyError> {
    //         unreachable!("snapshotting!")
    //     }

    //     fn check_write(&mut self, _path: &Path, _api_name: &str) -> Result<(), AnyError> {
    //         unreachable!("snapshotting!")
    //     }
    // }

    deno_core::extension!(runtime,
        deps = [
            deno_webidl,
            deno_console,
            deno_url,
            deno_tls,
            deno_web,
            deno_fetch,
            deno_cache,
            deno_websocket,
            deno_webstorage,
            deno_crypto,
            deno_broadcast_channel,
            deno_node,
            // deno_ffi, // disabled
            deno_net,
            // deno_napi, // disabled
            deno_http,
            deno_io,
            deno_fs
        ],
        esm_entry_point = "ext:runtime/90_deno_ns.js",
        esm = [
            dir "js_libs/deno",
            "01_errors.js",
            "01_version.ts",
            "06_util.js",
            "10_permissions.js",
            "11_workers.js",
            "13_buffer.js",
            "30_os.js",
            "40_fs_events.js",
            "40_http.js",
            "40_process.js",
            "40_signals.js",
            "40_tty.js",
            "41_prompt.js",
            "90_deno_ns.js",
            "98_global_scope.js"
        ],
        customizer = |ext: &mut Extension| {
            ext.esm_files.to_mut().push(ExtensionFileSource {
                specifier: "ext:runtime_main/js/99_main.js",
                code: ExtensionFileSourceCode::IncludedInBinary(
                    include_str!("./js_libs/deno/99_main.js"),
                ),
            });
            ext.esm_entry_point = Some("ext:runtime_main/js/99_main.js");
        }
    );

    deno_core::extension!(lit,
        deps = [runtime],
        esm_entry_point = "ext:lit/99_patches.js",
        esm = [
            dir "js_libs/lit",
            "00_ethers.js",
            "01_uint8arrays.js",
            "02_litActionsSDK.js",
            "03_jsonwebtoken.js",
        ],
        customizer = |ext: &mut Extension| {
            ext.esm_files.to_mut().push(ExtensionFileSource {
                specifier: "ext:lit/99_patches.js",
                code: ExtensionFileSourceCode::IncludedInBinary(
                    include_str!("js_libs/lit/99_patches.js"),
                ),
            });
        }
    );

    pub fn create_runtime_snapshot(snapshot_path: std::path::PathBuf) {
        // NOTE(bartlomieju): ordering is important here, keep it in sync with
        // `runtime/worker.rs`, `runtime/web_worker.rs` and `cli/build.rs`!

        let fs = std::sync::Arc::new(deno_fs::RealFs);
        let mut extensions: Vec<Extension> = vec![
            deno_webidl::deno_webidl::init_ops_and_esm(),
            deno_console::deno_console::init_ops_and_esm(),
            deno_url::deno_url::init_ops_and_esm(),
            deno_web::deno_web::init_ops_and_esm::<Permissions>(
                Default::default(),
                Default::default(),
            ),
            deno_fetch::deno_fetch::init_ops_and_esm::<Permissions>(Default::default()),
            deno_cache::deno_cache::init_ops_and_esm::<SqliteBackedCache>(None),
            deno_websocket::deno_websocket::init_ops_and_esm::<Permissions>(
                "".to_owned(),
                None,
                None,
            ),
            deno_webstorage::deno_webstorage::init_ops_and_esm(None),
            deno_crypto::deno_crypto::init_ops_and_esm(None),
            deno_broadcast_channel::deno_broadcast_channel::init_ops_and_esm(
                deno_broadcast_channel::InMemoryBroadcastChannel::default(),
            ),
            // deno_ffi::deno_ffi::init_ops_and_esm::<Permissions>(false), // disabled
            deno_net::deno_net::init_ops_and_esm::<Permissions>(None, None),
            deno_tls::deno_tls::init_ops_and_esm(),
            // deno_kv::deno_kv::init_ops_and_esm( // disabled
            //     deno_kv::sqlite::SqliteDbHandler::<Permissions>::new(None),
            //     false, // No --unstable
            // ),
            // deno_napi::deno_napi::init_ops_and_esm::<Permissions>(), // disabled
            deno_http::deno_http::init_ops_and_esm::<DefaultHttpPropertyExtractor>(),
            deno_io::deno_io::init_ops_and_esm(Default::default()),
            deno_fs::deno_fs::init_ops_and_esm::<Permissions>(fs.clone()),
            deno_node::deno_node::init_ops_and_esm::<Permissions>(None, fs),
            runtime::init_ops_and_esm(),
            lit::init_ops_and_esm(),
        ];

        for extension in &mut extensions {
            for source in extension.esm_files.to_mut() {
                maybe_transpile_source(source).unwrap();
            }
            for source in extension.js_files.to_mut() {
                maybe_transpile_source(source).unwrap();
            }
        }

        let output = create_snapshot(CreateSnapshotOptions {
            cargo_manifest_dir: env!("CARGO_MANIFEST_DIR"),
            snapshot_path,
            startup_snapshot: None,
            extensions,
            compression_cb: None,
            with_runtime_cb: None,
        });
        for path in output.files_loaded_during_snapshot {
            println!("cargo:rerun-if-changed={}", path.display());
        }
    }
}

fn main() {
    #[cfg(feature = "lit-actions")]
    {
        use std::env;
        use std::path::PathBuf;

        // To debug snapshot issues uncomment:
        // op_fetch_asset::trace_serializer();

        println!("cargo:rustc-env=TARGET={}", env::var("TARGET").unwrap());
        println!("cargo:rustc-env=PROFILE={}", env::var("PROFILE").unwrap());
        let o = PathBuf::from(env::var_os("OUT_DIR").unwrap());

        // Main snapshot
        let runtime_snapshot_path = o.join("RUNTIME_SNAPSHOT.bin");

        // If we're building on docs.rs we just create
        // and empty snapshot file and return, because `rusty_v8`
        // doesn't actually compile on docs.rs
        if env::var_os("DOCS_RS").is_some() {
            let snapshot_slice = &[];
            #[allow(clippy::needless_borrow)]
            #[allow(clippy::disallowed_methods)]
            std::fs::write(&runtime_snapshot_path, snapshot_slice).unwrap();
        }

        #[cfg(all(not(feature = "docsrs"), not(feature = "dont_create_runtime_snapshot")))]
        startup_snapshot::create_runtime_snapshot(runtime_snapshot_path)
    }
}
