#!/bin/bash

sudo systemctl start lit-node@{0..2}