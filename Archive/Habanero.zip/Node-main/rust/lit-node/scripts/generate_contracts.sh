#!/bin/bash

cd ../lit-core/lit-blockchain
./scripts/generate_contracts.sh