#!/bin/sh

[ -d "./node_keys/bls" ] && rm -rf ./node_keys/bls/secrets_*.bin