#!/bin/sh

rm -rf node_*.db