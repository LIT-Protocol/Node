#!/bin/bash

cargo release version patch --execute --no-confirm