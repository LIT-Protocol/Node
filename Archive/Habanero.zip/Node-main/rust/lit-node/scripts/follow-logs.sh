#!/bin/bash

sudo journalctl -u lit-node@0 -f
