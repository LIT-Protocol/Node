#!/bin/bash

sudo systemctl restart lit-node@{0..2}
