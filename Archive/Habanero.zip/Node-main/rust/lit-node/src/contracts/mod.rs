// Internal Contracts:
#[allow(clippy::module_inception)]
pub mod erc20;
