#!/bin/sh

sudo docker build -t glitch003/lit-protocol -f Dockerfile .
