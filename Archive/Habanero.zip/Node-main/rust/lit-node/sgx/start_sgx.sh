#!/bin/bash

sudo LIT_NODE_PORT=7470 graphene-sgx lit_node



# /usr/lib/x86_64-linux-gnu/gramine/


#fs.mount.lib.uri = "file:/usr/local/lib/x86_64-linux-gnu/graphene/runtime/glibc"