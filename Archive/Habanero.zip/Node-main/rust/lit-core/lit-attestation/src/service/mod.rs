#[cfg(feature = "generate-via-service")]
pub(crate) mod client;
pub mod types;
