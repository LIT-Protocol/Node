pub const ENV_CACHE_PATH_KEY: &str = "LIT_CORE_CACHE_PATH";
pub const ENV_CACHE_PATH_DEFAULT: &str = "/var/cache/lit-core";
