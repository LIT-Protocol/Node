pub trait Description {
    fn description(&self) -> Option<String>;
}
