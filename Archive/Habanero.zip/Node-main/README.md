<div align="center">
<h1>Lit Protocol Node and Contracts</h1>
<img src="https://i.ibb.co/p2xfzK1/Screenshot-2022-11-15-at-09-56-57.png">
<br/>
<a href="https://twitter.com/LitProtocol"><img src="https://img.shields.io/twitter/follow/litprotocol?label=Follow&style=social"/></a>
<br/>
<br/>
The Lit Protocol Node is the core software that runs the Lit Protocol. It is a Rust application that node operators run to provide service to Lit Protocol.
<br/>
<br/>

<a href="https://developer.litprotocol.com/v3/sdk/installation"><img src="https://i.ibb.co/fDqdXLq/button-go-to-docs.png" /></a>

<a href="https://developer.litprotocol.com/v3/sdk/installation">
https://developer.litprotocol.com/v3/sdk/installation
</a>

<br/><br/>
This is a monorepo that holds everything needed to run a Lit Node. Check out the readme in each folder for more information.

</div>

<div align="left">

## Contents

### Rust

- [lit-core](rust/lit-core) ([README.md](rust/lit-core/README.md))
- [lit-node](rust/lit-node) ([README.md](rust/lit-node/README.md))
- [lit-os](rust/lit-os) ([README.md](rust/lit-os/README.md))

### Blockchain / Contracts

- [lit-node](blockchain/contracts/lit-node) ([README.md](blockchain/contracts/lit-node/README.md))
- [lit-os](blockchain/contracts/lit-os) ([README.md](blockchain/contracts/lit-os/README.md))

</div>
