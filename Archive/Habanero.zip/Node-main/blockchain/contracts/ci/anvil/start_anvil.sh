#!/bin/sh

anvil -a 10 --host 0.0.0.0 > anvil.log 2>&1