# Build

```bash
docker build . -t anvil
```

# Run

```bash
docker run anvil
```

# Debug

```bash
docker exec -it <CONTAINER_ID> /bin/sh
```
