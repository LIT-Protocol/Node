#!/bin/bash

npx hardhat verify --network $@