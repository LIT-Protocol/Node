#!/bin/zsh

remixd -s . -u http://localhost:2020